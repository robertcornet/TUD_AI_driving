from setuptools import setup


setup(name='mujoco',
      version='0.0.1',
      install_requires=['gym>=0.2.3']
)

setup(name='classic_control',
      version='0.0.1',
      install_requires=['gym>=0.2.3']
)

setup(name='atari',
      version='0.0.1',
      install_requires=['gym>=0.2.3']
)

